<?php
  $ranga = $_SESSION['user_rang']; // ranga użytkownika (0 - użytkownika, 1 - admin, 2 - moderator)
  $login = $_SESSION['user_login']; // login użytkownika
  $imie = $_SESSION['user_name']; // imię użytkownika
  $nazwisko = $_SESSION['user_lastname']; // nazwisko użytkownika
?>
